setInterval(replaceByTag, 5000);
function replaceByTag(){
	//tag <span>
	var x = document.getElementsByTagName("SPAN");
	for (i = 0; i < x.length; i++){
		if (x[i].attributes.length == 0){
			for (j = keyComb.length - 1; j >= 0; j--){
				if (j + 1 < 80 || j + 1 > 99){
					if (x[i].innerHTML.includes(keyComb[j])){
						x[i].innerHTML = x[i].innerHTML.replace(keyComb[j], getCode(j));		
					}	
				}
			}
			
		}	
	}

	//tag <p>
	x = document.getElementsByTagName("P");
	for (i = 0; i < x.length; i++){
		if (x[i].attributes.length == 0){
			for (j = keyComb.length - 1; j >= 0; j--){
				if (j + 1 < 80 || j + 1 > 99){
					if (x[i].innerHTML.includes(keyComb[j])){
						x[i].innerHTML = x[i].innerHTML.replace(keyComb[j], getCode(j));		
					}	
				}
			}
			
		}	
	}
}
function getCode(id){
	var res = "<img src=\"http://l.yimg.com/us.yimg.com/i/mesg/emoticons7/" + (id + 1) + ".gif\">";
	return res;
}
var keyComb = [
		":)",
		":(",
		";)",
		":D",
		";;)",
		">:D<",
		":-/",
		":x",
		":\">",
		":P",
		":-*",
		"=((",
		":-O",
		"X(",
		":>",
		"B-)",
		":-S",
		"#:-S",
		">:)",
		":((",
		":))",
		":|",
		"/:)",
		"=))",
		"O:-)",
		":-B",
		"=;",
		"I-)",
		"8-|",
		"L-)",
		":-&",
		":-$",
		"[-(",
		":O)",
		"8-}",
		"<:-P",
		"(:|",
		"=P~",
		":-?",
		"#-o",
		"=D>",
		":-SS",
		"@-)",
		":^o",
		":-w",
		":-<",
		">:P",
		"<):)",
		":@)",
		"3:-O",
		":(|)",
		"~:>",
		"@};-",
		"%%-",
		"**==",
		"(~~)",
		"~O)",
		"*-:)",
		"8-X",
		"=:)",
		">-)",
		":-L",
		"[-O<",
		"$-)",
		":-\"",
		"b-(",
		":)>-",
		"[-X",
		"\\:D/",
		">:/",
		";))",
		"o->",
		"o=>",
		"o-+",
		"(%)",
		":-@",
		"^:)^",
		":-j",
		"(*)",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		":)]",
		":-c",
		"~X(",
		":-h",
		":-t",
		"8->",
		":-??",
		"%-(",
		":o3",
		"X_X",
		":!!",
		"\\m/",
		":-q",
		":-bd",
		"^#(^",
		":bz",
];